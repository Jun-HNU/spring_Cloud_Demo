package com.zsy.common.to;

import lombok.Data;

/**
 * @author: zhangshuaiyin
 * @date: 2021/3/13 10:21
 */
@Data
public class SkuHasStockVo {

    private Long skuId;

    private Boolean hasStock;

}
