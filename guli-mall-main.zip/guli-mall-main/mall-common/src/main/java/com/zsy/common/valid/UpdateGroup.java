package com.zsy.common.valid;

/**
 * 更新校验分组
 *
 * @author ZSY
 */
public interface UpdateGroup {
}
