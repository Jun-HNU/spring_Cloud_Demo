package com.zsy.common.valid;

public interface UpdateStatusGroup {
}
