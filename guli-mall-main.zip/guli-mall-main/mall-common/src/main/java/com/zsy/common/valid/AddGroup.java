package com.zsy.common.valid;

/**
 * 新增校验分组
 *
 * @author ZSY
 */
public interface AddGroup {
}
