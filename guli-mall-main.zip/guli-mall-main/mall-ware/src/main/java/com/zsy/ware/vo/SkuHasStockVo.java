package com.zsy.ware.vo;

import lombok.Data;

/**
 * @Description:
 * @Created: with IntelliJ IDEA.
 * @author: 夏沫止水
 * @createTime: 2020-06-06 15:38
 **/

@Data
public class SkuHasStockVo {

    private Long skuId;

    private Boolean hasStock;

}
