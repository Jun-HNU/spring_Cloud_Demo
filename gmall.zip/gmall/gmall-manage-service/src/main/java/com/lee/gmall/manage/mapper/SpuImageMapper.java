package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SpuImage;
import tk.mybatis.mapper.common.Mapper;

public interface SpuImageMapper extends Mapper<SpuImage> {
}
