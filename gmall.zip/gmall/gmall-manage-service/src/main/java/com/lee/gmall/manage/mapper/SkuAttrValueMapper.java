package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SkuAttrValue;
import tk.mybatis.mapper.common.Mapper;

public interface SkuAttrValueMapper extends Mapper<SkuAttrValue> {
}
