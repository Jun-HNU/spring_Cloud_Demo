package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.BaseCatalog3;
import tk.mybatis.mapper.common.Mapper;

public interface BaseCatalog3Mapper extends Mapper<BaseCatalog3> {
}
