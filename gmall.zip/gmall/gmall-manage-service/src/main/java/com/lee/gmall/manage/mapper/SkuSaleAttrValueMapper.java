package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SkuSaleAttrValue;
import tk.mybatis.mapper.common.Mapper;

public interface SkuSaleAttrValueMapper extends Mapper<SkuSaleAttrValue> {
}
