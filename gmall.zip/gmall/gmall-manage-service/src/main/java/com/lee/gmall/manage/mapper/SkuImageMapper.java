package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SkuImage;
import tk.mybatis.mapper.common.Mapper;

public interface SkuImageMapper extends Mapper<SkuImage> {
}
