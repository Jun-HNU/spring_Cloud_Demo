package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.BaseAttrInfo;
import tk.mybatis.mapper.common.Mapper;

public interface BaseAttrInfoMapper extends Mapper<BaseAttrInfo> {
}
