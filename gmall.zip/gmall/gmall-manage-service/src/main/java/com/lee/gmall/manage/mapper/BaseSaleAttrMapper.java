package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.BaseSaleAttr;
import tk.mybatis.mapper.common.Mapper;

public interface BaseSaleAttrMapper extends Mapper<BaseSaleAttr> {
}
