package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.BaseCatalog2;
import tk.mybatis.mapper.common.Mapper;

public interface BaseCatalog2Mapper extends Mapper<BaseCatalog2> {
}
