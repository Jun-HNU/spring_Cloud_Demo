package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SpuInfo;
import tk.mybatis.mapper.common.Mapper;

public interface SpuInfoMapper extends Mapper<SpuInfo > {
}
