package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SpuSaleAttr;
import tk.mybatis.mapper.common.Mapper;

public interface SpuSaleAttrMapper extends Mapper<SpuSaleAttr> {
}
