package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.SkuInfo;
import tk.mybatis.mapper.common.Mapper;

public interface SkuInfoMapper extends Mapper<SkuInfo> {
}
