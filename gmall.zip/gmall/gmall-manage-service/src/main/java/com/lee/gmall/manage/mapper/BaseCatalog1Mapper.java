package com.lee.gmall.manage.mapper;

import com.lee.gmall.bean.BaseCatalog1;
import tk.mybatis.mapper.common.Mapper;

public interface BaseCatalog1Mapper extends Mapper<BaseCatalog1> {
}
