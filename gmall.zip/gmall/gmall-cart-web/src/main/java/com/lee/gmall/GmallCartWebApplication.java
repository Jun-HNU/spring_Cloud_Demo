package com.lee.gmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GmallCartWebApplication {



    public static void main(String[] args) {
        SpringApplication.run(GmallCartWebApplication.class, args);
    }

}
