package com.lee.gmall.bean;


public class BaseCatalog1Tm {

  private long id;
  private long tmId;
  private String catalog1Id;


  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }


  public long getTmId() {
    return tmId;
  }

  public void setTmId(long tmId) {
    this.tmId = tmId;
  }


  public String getCatalog1Id() {
    return catalog1Id;
  }

  public void setCatalog1Id(String catalog1Id) {
    this.catalog1Id = catalog1Id;
  }

}
