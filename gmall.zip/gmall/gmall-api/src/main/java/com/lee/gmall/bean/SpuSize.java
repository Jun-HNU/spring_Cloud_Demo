package com.lee.gmall.bean;


public class SpuSize {

  private long id;
  private long spuId;
  private String spuSize;
  private String isEnabled;


  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }


  public long getSpuId() {
    return spuId;
  }

  public void setSpuId(long spuId) {
    this.spuId = spuId;
  }


  public String getSpuSize() {
    return spuSize;
  }

  public void setSpuSize(String spuSize) {
    this.spuSize = spuSize;
  }


  public String getIsEnabled() {
    return isEnabled;
  }

  public void setIsEnabled(String isEnabled) {
    this.isEnabled = isEnabled;
  }

}
