package com.lee.gmall.bean;


public class AdBanner {

  private long id;
  private String adDesc;
  private String fileName;


  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }


  public String getAdDesc() {
    return adDesc;
  }

  public void setAdDesc(String adDesc) {
    this.adDesc = adDesc;
  }


  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

}
