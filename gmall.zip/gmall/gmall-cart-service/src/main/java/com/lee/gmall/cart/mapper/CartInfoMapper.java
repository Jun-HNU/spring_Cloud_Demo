package com.lee.gmall.cart.mapper;

import com.lee.gmall.bean.CartInfo;
import tk.mybatis.mapper.common.Mapper;

public interface CartInfoMapper extends Mapper<CartInfo> {
}
